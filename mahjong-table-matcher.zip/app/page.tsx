"use client"

import { useEffect, useMemo, useState, useCallback } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Upload, Plus, X, Users, ShieldAlert, CheckCircle } from "lucide-react"

const APP_PASSWORD = "Admin123!"

interface Rule {
  member: string
  avoid: string
}

export default function MahjongTableMatcher() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [password, setPassword] = useState("")
  const [error, setError] = useState(false)

  const handleLogin = () => {
    if (password === APP_PASSWORD) {
      setLoggedIn(true)
      setError(false)
    } else {
      setError(true)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleLogin()
    }
  }

  if (!loggedIn) {
    return (
      <div className="min-h-screen bg-amber-50 flex items-center justify-center p-6">
        <Card className="w-full max-w-md shadow-xl border-amber-200">
          <CardContent className="p-8 space-y-6 text-center">
            <div className="flex flex-col items-center gap-3">
              <img
                src="/logo.jpg"
                alt="世富 Logo"
                className="w-28 h-28 object-contain rounded-xl"
              />
              <h1 className="text-2xl font-bold text-amber-900">世富配桌系統</h1>
              <p className="text-amber-700">請輸入管理密碼</p>
            </div>
            <div className="space-y-3">
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value)
                  setError(false)
                }}
                onKeyDown={handleKeyDown}
                className={`text-center ${error ? "border-red-500 focus-visible:ring-red-500" : "border-amber-300 focus-visible:ring-amber-500"}`}
              />
              {error && (
                <p className="text-red-500 text-sm">密碼錯誤，請重試</p>
              )}
              <Button
                className="w-full bg-amber-600 hover:bg-amber-700 text-white"
                onClick={handleLogin}
              >
                登入
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-amber-50 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        <header className="flex flex-col items-center gap-3 pb-4 border-b border-amber-200">
          <img
            src="/logo.jpg"
            alt="世富 Logo"
            className="w-20 h-20 object-contain rounded-xl"
          />
          <h1 className="text-3xl font-bold text-amber-900">
            🀄 世富配桌系統
          </h1>
        </header>
        <MainApp />
      </div>
    </div>
  )
}

function MainApp() {
  const [players, setPlayers] = useState<string[]>(["", "", "", ""])
  const [member, setMember] = useState("")
  const [avoid, setAvoid] = useState("")
  const [rules, setRules] = useState<Rule[]>([])

  const handleExcelImport = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (!file) return

      try {
        const data = await file.arrayBuffer()
        const XLSX = await import("xlsx")
        const workbook = XLSX.read(data)
        const sheet = workbook.Sheets[workbook.SheetNames[0]]
        const rows = XLSX.utils.sheet_to_json<string[]>(sheet, { header: 1 })

        const imported: Rule[] = []
        rows.forEach((row) => {
          const memberName = row[0]
          if (!memberName) return
          row.slice(2).forEach((avoidName) => {
            if (avoidName) {
              imported.push({ member: String(memberName), avoid: String(avoidName) })
            }
          })
        })

        setRules((prev) => {
          const combined = [...prev, ...imported]
          const unique = combined.filter(
            (rule, index, self) =>
              index ===
              self.findIndex(
                (r) => r.member === rule.member && r.avoid === rule.avoid
              )
          )
          return unique
        })
      } catch (err) {
        console.error("Excel import error:", err)
      }

      e.target.value = ""
    },
    []
  )

  useEffect(() => {
    const saved = localStorage.getItem("mahjong-rules")
    if (saved) {
      try {
        setRules(JSON.parse(saved))
      } catch {
        // Invalid JSON, ignore
      }
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("mahjong-rules", JSON.stringify(rules))
  }, [rules])

  const conflicts = useMemo(() => {
    const found: string[] = []
    const filledPlayers = players.filter((p) => p.trim())

    for (const r of rules) {
      if (filledPlayers.includes(r.member) && filledPlayers.includes(r.avoid)) {
        found.push(`${r.member} 不跟 ${r.avoid} 打`)
      }
    }
    return [...new Set(found)]
  }, [players, rules])

  const addRule = () => {
    if (!member.trim() || !avoid.trim()) return
    const exists = rules.some(
      (r) => r.member === member.trim() && r.avoid === avoid.trim()
    )
    if (!exists) {
      setRules([...rules, { member: member.trim(), avoid: avoid.trim() }])
    }
    setMember("")
    setAvoid("")
  }

  const removeRule = (index: number) => {
    setRules(rules.filter((_, idx) => idx !== index))
  }

  const updatePlayer = (index: number, value: string) => {
    const newPlayers = [...players]
    newPlayers[index] = value
    setPlayers(newPlayers)
  }

  const clearAllRules = () => {
    if (confirm("確定要清除所有禁配名單嗎？")) {
      setRules([])
    }
  }

  const filledPlayers = players.filter((p) => p.trim()).length
  const hasEnoughPlayers = filledPlayers === 4

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {/* Player Input Card */}
      <Card className="shadow-lg border-amber-200">
        <CardContent className="p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-600" />
            <h2 className="text-xl font-semibold text-amber-900">
              輸入四位玩家
            </h2>
          </div>

          <div className="space-y-3">
            {players.map((p, i) => (
              <Input
                key={i}
                placeholder={`玩家 ${i + 1}`}
                value={p}
                onChange={(e) => updatePlayer(i, e.target.value)}
                className="border-amber-300 focus-visible:ring-amber-500"
              />
            ))}
          </div>

          <div className="text-sm text-amber-700">
            已輸入 {filledPlayers} / 4 位玩家
          </div>

          {/* Status Display */}
          <div
            className={`p-4 rounded-xl font-semibold transition-colors ${
              !hasEnoughPlayers
                ? "bg-amber-100 text-amber-700"
                : conflicts.length > 0
                  ? "bg-red-100 text-red-700"
                  : "bg-green-100 text-green-700"
            }`}
          >
            {!hasEnoughPlayers ? (
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                <span>請輸入四位玩家姓名</span>
              </div>
            ) : conflicts.length > 0 ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5" />
                  <span>有禁配衝突：</span>
                </div>
                <ul className="ml-7 space-y-1">
                  {conflicts.map((c, i) => (
                    <li key={i}>• {c}</li>
                  ))}
                </ul>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                <span>✅ 成局！四位玩家可以同桌</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Rules Management Card */}
      <Card className="shadow-lg border-amber-200">
        <CardContent className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-600" />
              <h2 className="text-xl font-semibold text-amber-900">
                禁配名單管理
              </h2>
            </div>
            <span className="text-sm text-amber-600 bg-amber-100 px-2 py-1 rounded-full">
              {rules.length} 條規則
            </span>
          </div>

          {/* Excel Import */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-amber-800">
              從 Excel 匯入
            </label>
            <div className="relative">
              <Input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleExcelImport}
                className="border-amber-300 file:bg-amber-100 file:text-amber-700 file:border-0 file:mr-3 file:px-3 file:py-1 file:rounded-md cursor-pointer"
              />
            </div>
            <p className="text-xs text-amber-600">
              格式：第一欄為會員姓名，第三欄起為禁配對象
            </p>
          </div>

          {/* Manual Add */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-amber-800">
              手動新增
            </label>
            <div className="flex gap-2">
              <Input
                placeholder="會員姓名"
                value={member}
                onChange={(e) => setMember(e.target.value)}
                className="border-amber-300 focus-visible:ring-amber-500"
              />
              <Input
                placeholder="不跟誰打"
                value={avoid}
                onChange={(e) => setAvoid(e.target.value)}
                className="border-amber-300 focus-visible:ring-amber-500"
                onKeyDown={(e) => e.key === "Enter" && addRule()}
              />
            </div>
            <Button
              onClick={addRule}
              className="w-full bg-amber-600 hover:bg-amber-700 text-white"
              disabled={!member.trim() || !avoid.trim()}
            >
              <Plus className="w-4 h-4 mr-2" />
              新增規則
            </Button>
          </div>

          {/* Rules List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium text-amber-800">
                目前禁配名單
              </label>
              {rules.length > 0 && (
                <button
                  onClick={clearAllRules}
                  className="text-xs text-red-500 hover:text-red-700 transition-colors"
                >
                  清除全部
                </button>
              )}
            </div>
            <div className="space-y-2 max-h-64 overflow-auto pr-1">
              {rules.length === 0 ? (
                <div className="text-center py-8 text-amber-500">
                  <Upload className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">尚無禁配規則</p>
                  <p className="text-xs">匯入 Excel 或手動新增</p>
                </div>
              ) : (
                rules.map((r, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between bg-amber-50 border border-amber-200 p-3 rounded-lg group hover:bg-amber-100 transition-colors"
                  >
                    <span className="text-amber-900">
                      <span className="font-medium">{r.member}</span>
                      <span className="mx-2 text-amber-400">×</span>
                      <span className="font-medium">{r.avoid}</span>
                    </span>
                    <button
                      onClick={() => removeRule(i)}
                      className="text-amber-400 hover:text-red-500 transition-colors p-1 rounded-full hover:bg-red-50"
                      aria-label={`刪除 ${r.member} 與 ${r.avoid} 的禁配規則`}
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
